const state = {
  loggedIn: false,
  username: "",
  email: "",
  startTime: "",
  endTime: "",
  appointment: [],
};

export default state;
